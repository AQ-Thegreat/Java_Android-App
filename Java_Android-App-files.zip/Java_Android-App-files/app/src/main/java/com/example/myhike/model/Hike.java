package com.example.myhike.model;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import org.parceler.Parcel;


@Parcel
@Entity(tableName = "hikes")
public class Hike {

    public Hike() {
    }
    @PrimaryKey(autoGenerate = true)
    private long id;

    private String hikeName;
    private String date;
    private String location;
    private String parkingAvailable;
    private float length;
    private String difficultyLevel;
    private String description;


    public Hike(String hikeName, String date, String location, String parkingAvailable,
                float length, String difficultyLevel, String description) {
        this.hikeName = hikeName;
        this.date = date;
        this.location = location;
        this.parkingAvailable = parkingAvailable;
        this.length = length;
        this.difficultyLevel = difficultyLevel;
        this.description = description;
    }

    // Getters and Setters for fields

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getHikeName() {
        return hikeName;
    }

    public void setHikeName(String hikeName) {
        this.hikeName = hikeName;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getParkingAvailable() {
        return parkingAvailable;
    }

    public void setParkingAvailable(String parkingAvailable) {
        this.parkingAvailable = parkingAvailable;
    }

    public float getLength() {
        return length;
    }

    public void setLength(float length) {
        this.length = length;
    }

    public String getDifficultyLevel() {
        return difficultyLevel;
    }

    public void setDifficultyLevel(String difficultyLevel) {
        this.difficultyLevel = difficultyLevel;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @NonNull
    public String toString() {
        return hikeName + " " + date;
    }

}
