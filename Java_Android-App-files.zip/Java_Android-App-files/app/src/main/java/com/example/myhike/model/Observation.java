package com.example.myhike.model;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

import org.parceler.Parcel;

@Parcel
@Entity(
        tableName = "observations",
        foreignKeys = @ForeignKey(
                entity = Hike.class,
                parentColumns = "id",
                childColumns = "hikeId",
                onDelete = ForeignKey.CASCADE
        )
)
public class Observation {

public  Observation() {
}
    @PrimaryKey(autoGenerate = true)
    private long id;

    private long hikeId;
    private String observation;
    private String time;
    private String additionalComments;

    public Observation(long hikeId, String observation, String time, String additionalComments) {
        this.hikeId = hikeId;
        this.observation = observation;
        this.time = time;
        this.additionalComments = additionalComments;
    }


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getHikeId() {
        return hikeId;
    }

    public void setHikeId(long hikeId) {
        this.hikeId = hikeId;
    }

    public String getObservation() {
        return observation;
    }

    public void setObservation(String observation) {
        this.observation = observation;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getAdditionalComments() {
        return additionalComments;
    }

    public void setAdditionalComments(String additionalComments) {
        this.additionalComments = additionalComments;
    }
    @NonNull
    public String toString() {
        return observation + " " + time;
    }
}
