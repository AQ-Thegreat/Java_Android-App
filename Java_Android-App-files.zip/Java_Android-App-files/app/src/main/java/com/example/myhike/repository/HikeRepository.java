package com.example.myhike.repository;


import android.content.Context;

import java.util.ArrayList;
import java.util.List;
import com.example.myhike.db.AppDatabase;
import com.example.myhike.model.Hike;
import com.example.myhike.model.Observation;

public class HikeRepository {

    private AppDatabase mAppDatabase;

    public HikeRepository(Context context) {
        mAppDatabase = AppDatabase.getInstance(context);
    }

    public List<Hike> getAllHikes() {
        return mAppDatabase.hikeDao().getAllHikes();
    }

    public Hike getHikeById(long hikeId) {
        return mAppDatabase.hikeDao().getHikeById(hikeId);
    }
public void resetDatabase(){
    mAppDatabase.clearAllTables();
}
    public void insertHike(Hike hike) {
        mAppDatabase.hikeDao().insertHike(hike);
    }

    public void updateHike(Hike hike) {
        mAppDatabase.hikeDao().updateHike(hike);
    }

    public void deleteHike(Hike hike) {
        mAppDatabase.hikeDao().deleteHike(hike);
    }

    public List<Observation> getObservationsForHike(long hikeId) {
        return mAppDatabase.hikeDao().getObservationsForHike(hikeId);
    }
    public List<Hike> searchHikesByName(String query) {
        return mAppDatabase.hikeDao().searchHikesByName("%" + query + "%");
    }

    public void insertObservation(Observation observation) {
        mAppDatabase.hikeDao().insertObservation(observation);
    }

    public void updateObservation(Observation observation) {
        mAppDatabase.hikeDao().updateObservation(observation);
    }

    public void deleteObservation(Observation observation) {
        mAppDatabase.hikeDao().deleteObservation(observation);
    }

    public void insertSampleHikes() {
        List<Hike> sampleHikes = new ArrayList<>();

        // Creating sample hike data
        Hike hike1 = new Hike("Mount XYZ Trail", "2023-11-20", "Location A",
                "Parking available", 5.2f, "Moderate", "Scenic trail with moderate difficulty");
        Hike hike2 = new Hike("River Valley Loop", "2023-11-25", "Location B",
                "No parking available", 3.8f, "Easy", "Beautiful loop trail along the river");

        // Adding hikes to the list
        sampleHikes.add(hike1);
        sampleHikes.add(hike2);

        // Insert sample hikes into the database
        for (Hike hike : sampleHikes) {
            mAppDatabase.hikeDao().insertHike(hike);
        }
    }
}