package com.example.myhike;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.widget.AppCompatSpinner;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.example.myhike.model.Hike;
import com.example.myhike.repository.HikeRepository;

import org.parceler.Parcels;

import java.util.Calendar;

public class HikeFormFragment extends Fragment {

    private EditText editTextHikeName;
    private EditText editTextDate;
    private EditText editTextLocation;
    private EditText editTextParkingAvailable;
    private EditText editTextLength;
    private EditText editTextDifficultyLevel;
    private EditText editTextDescription;
    private String selectedParking;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_hike_form, container, false);

        editTextHikeName = view.findViewById(R.id.editTextHikeName);
        editTextDate = view.findViewById(R.id.editTextDate);
        editTextDate.setOnClickListener(v -> showDatePickerDialog());
        editTextLocation = view.findViewById(R.id.editTextLocation);
        editTextLength = view.findViewById(R.id.editTextLength);
        editTextDifficultyLevel = view.findViewById(R.id.editTextDifficultyLevel);
        editTextDescription = view.findViewById(R.id.editTextDescription);
        AppCompatSpinner spinnerParkingAvailable = view.findViewById(R.id.spinnerParkingAvailable);

        String[] parkingOptions = {"Yes", "No"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(), R.layout.custom_spinner_dropdown_item, parkingOptions);
        adapter.setDropDownViewResource(R.layout.custom_spinner_dropdown_item);
        spinnerParkingAvailable.setAdapter(adapter);
        spinnerParkingAvailable.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedParking = parkingOptions[position];
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        Bundle args = getArguments();
        if (args != null && args.containsKey("selected_hike")) {
            Hike selectedHike = Parcels.unwrap(args.getParcelable("selected_hike"));
            if (selectedHike != null) {
                String previouslySelectedParking = ""; // Replace this with the field in your Hike object
                int position = getPositionFromArray(previouslySelectedParking, parkingOptions);
                if (position != -1) {
                    spinnerParkingAvailable.setSelection(position);
                }
                editTextHikeName.setText(selectedHike.getHikeName());
                editTextDate.setText(selectedHike.getDate());
                editTextLocation.setText(selectedHike.getLocation());
                selectedParking = selectedHike.getParkingAvailable();
                editTextLength.setText(String.valueOf(selectedHike.getLength()));
                editTextDifficultyLevel.setText(selectedHike.getDifficultyLevel());
                editTextDescription.setText(selectedHike.getDescription());
            }
        }

        Button btnSave = view.findViewById(R.id.buttonSave);
        btnSave.setOnClickListener(v -> saveHike());

        return view;
    }
    private int getPositionFromArray(String value, String[] array) {
        for (int i = 0; i < array.length; i++) {
            if (array[i].equals(value)) {
                return i;
            }
        }
        return -1; // Return -1 if the value is not found
    }
    private void showDatePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                requireContext(),
                (view, selectedYear, selectedMonth, selectedDayOfMonth) -> {
                    String selectedDate = selectedYear + "-" + (selectedMonth + 1) + "-" + selectedDayOfMonth;
                    editTextDate.setText(selectedDate);
                },
                year, month, dayOfMonth);

        datePickerDialog.show();
    }
    private void saveHike() {
        String hikeName = editTextHikeName.getText().toString().trim();
        String date = editTextDate.getText().toString().trim();
        String location = editTextLocation.getText().toString().trim();
        String parkingAvailable = selectedParking;
        String lengthText = editTextLength.getText().toString().trim();
        String difficultyLevel = editTextDifficultyLevel.getText().toString().trim();
        String description = editTextDescription.getText().toString().trim();

        // Perform validation for required fields
        if (hikeName.isEmpty() || date.isEmpty() || location.isEmpty() ||
                parkingAvailable.isEmpty() || lengthText.isEmpty() || difficultyLevel.isEmpty()) {
            // Show an error message or handle accordingly (e.g., display a Toast)
            Toast.makeText(requireContext(), "Please fill in all required fields", Toast.LENGTH_SHORT).show();
            return; // Exit the function as required fields are not filled
        }

        // Parse the length value
        float length = 0.0f;
        try {
            length = Float.parseFloat(lengthText);
        } catch (NumberFormatException e) {
            // Handle the case where length is not a valid float value
            e.printStackTrace();
            Toast.makeText(requireContext(), "Invalid length value", Toast.LENGTH_SHORT).show();
            return; // Exit the function due to an invalid length value
        }

        ProgressDialog progressDialog = ProgressDialog.show(requireContext(), "Saving Hike", "Please wait...", true);
        if (description.isEmpty()) {
            description = "";
        }
        Hike hike = new Hike(hikeName, date, location, parkingAvailable, length, difficultyLevel, description);

        if (getArguments() != null && getArguments().containsKey("selected_hike")) {
            Bundle args = getArguments();
            Hike selectedHike = Parcels.unwrap(args.getParcelable("selected_hike"));
            hike.setId(selectedHike.getId());
            new UpdateHikeTask(progressDialog).execute(hike);
        } else {
            new InsertHikeTask(progressDialog).execute(hike);
        }
    }

    private class InsertHikeTask extends AsyncTask<Hike, Void, Void> {
        private ProgressDialog progressDialog;

        InsertHikeTask(ProgressDialog progressDialog) {
            this.progressDialog = progressDialog;
        }

        @Override
        protected Void doInBackground(Hike... hikes) {
            if (hikes != null && hikes.length > 0) {
                HikeRepository hikeRepository = new HikeRepository(requireContext());
                hikeRepository.insertHike(hikes[0]);
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            progressDialog.dismiss();
            Toast.makeText(requireContext(), "Hike saved successfully", Toast.LENGTH_SHORT).show();
            Bundle bundle = getArguments();
            Navigation.findNavController(requireView()).navigate(R.id.FirstFragment, bundle);
        }
    }

    private class UpdateHikeTask extends AsyncTask<Hike, Void, Void> {
        private ProgressDialog progressDialog;

        UpdateHikeTask(ProgressDialog progressDialog) {
            this.progressDialog = progressDialog;
        }

        @Override
        protected Void doInBackground(Hike... hikes) {
            if (hikes != null && hikes.length > 0) {
                HikeRepository hikeRepository = new HikeRepository(requireContext());
                hikeRepository.updateHike(hikes[0]);
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            progressDialog.dismiss();
            Toast.makeText(requireContext(), "Hike saved successfully", Toast.LENGTH_SHORT).show();
            Bundle bundle = getArguments();
            Navigation.findNavController(requireView()).navigate(R.id.FirstFragment, bundle);
        }
    }
}
