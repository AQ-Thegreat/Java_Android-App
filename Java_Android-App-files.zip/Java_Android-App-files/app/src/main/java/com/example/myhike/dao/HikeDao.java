package com.example.myhike.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import com.example.myhike.model.Hike;
import com.example.myhike.model.Observation;

@Dao
public interface HikeDao {

    // Queries related to hikes

    @Query("SELECT * FROM hikes")
    List<Hike> getAllHikes();

    @Query("SELECT * FROM hikes WHERE id = :hikeId")
    Hike getHikeById(long hikeId);

    @Insert
    long insertHike(Hike hike);

    @Update
    void updateHike(Hike hike);

    @Delete
    void deleteHike(Hike hike);

    @Query("SELECT * FROM hikes WHERE hikeName LIKE :nameQuery")
    List<Hike> searchHikesByName(String nameQuery);
    // Queries related to observations

    @Query("SELECT * FROM observations WHERE hikeId = :hikeId")
    List<Observation> getObservationsForHike(long hikeId);

    @Insert
    void insertObservation(Observation observation);

    @Update
    void updateObservation(Observation observation);

    @Delete
    void deleteObservation(Observation observation);
}
