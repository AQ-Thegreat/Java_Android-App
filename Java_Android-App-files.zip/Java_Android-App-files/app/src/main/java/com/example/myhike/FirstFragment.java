package com.example.myhike;

import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.example.myhike.model.Hike;
import com.example.myhike.repository.HikeRepository;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.parceler.Parcels;

import java.util.List;

public class FirstFragment extends Fragment {

    private HikeRepository hikeRepository;
    private ArrayAdapter<Hike> adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_first, container, false);

        hikeRepository = new HikeRepository(requireContext());
        ListView listView = view.findViewById(R.id.listView_hikes);

        adapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_list_item_1);
        listView.setAdapter(adapter);
        EditText editTextSearch = view.findViewById(R.id.editTextSearch);
        editTextSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String query = charSequence.toString().trim();
                performSearch(query);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        new LoadHikesTask(adapter).execute();

        listView.setOnItemClickListener((parent, view1, position, id) -> {
            Hike selectedHike = adapter.getItem(position);
            if (selectedHike != null) {
                Bundle bundle = new Bundle();
                bundle.putParcelable("selected_hike", Parcels.wrap(selectedHike));
                Navigation.findNavController(view)
                        .navigate(R.id.action_firstFragment_to_hikeDetailsFragment, bundle);
            }
        });
        FloatingActionButton fabAddHike = view.findViewById(R.id.fab_add_hike);
        fabAddHike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navigate to the Hike Form Fragment
                Navigation.findNavController(view)
                        .navigate(R.id.action_firstFragment_to_hikeFormFragment);
            }
        });
        return view;
    }
    private void performSearch(String query) {
        new SearchHikesTask().execute(query);
    }

    private class SearchHikesTask extends AsyncTask<String, Void, List<Hike>> {
        @Override
        protected List<Hike> doInBackground(String... queries) {
            if (queries.length > 0) {
                String query = queries[0];
                return hikeRepository.searchHikesByName(query);
            }
            return null;
        }

        @Override
        protected void onPostExecute(List<Hike> hikes) {
            super.onPostExecute(hikes);
            adapter.clear();
            if (hikes != null) {
                adapter.addAll(hikes);
            }
            adapter.notifyDataSetChanged();
        }
    }
    private class LoadHikesTask extends AsyncTask<Void, Void, List<Hike>> {
        private ArrayAdapter<Hike> adapter;

        LoadHikesTask(ArrayAdapter<Hike> adapter) {
            this.adapter = adapter;
        }

        @Override
        protected List<Hike> doInBackground(Void... voids) {
            return hikeRepository.getAllHikes();
        }

        @Override
        protected void onPostExecute(List<Hike> hikes) {
            super.onPostExecute(hikes);
            adapter.clear();
            adapter.addAll(hikes);
            adapter.notifyDataSetChanged();
        }
    }
}
