package com.example.myhike.util;
import com.example.myhike.model.Hike;
import java.util.ArrayList;
import java.util.List;

public class DataGenerate {
    public static List<Hike> generateHikes() {
        List<Hike> hikes = new ArrayList<>();
        hikes.add(new Hike("Hike 1", "2023-11-10", "Mountain Peak", "Yes", 5.2f, "Moderate",
                "Enjoy a scenic view and a moderate hike to the peak."));
    return hikes;
    }

}

