package com.example.myhike.model;

import androidx.room.Embedded;
import androidx.room.Relation;

import java.util.List;

public class HikeWithObservations {
    @Embedded
    public Hike hike;

    @Relation(
            parentColumn = "id",
            entityColumn = "hikeId"
    )
    public List<Observation> observations;
}