package com.example.myhike.model;
import androidx.room.TypeConverter;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.List;

public class ObservationListConverter {
    private static Gson gson = new Gson();

    @TypeConverter
    public static List<Observation> fromString(String value) {
        Type listType = new TypeToken<List<Observation>>() {}.getType();
        return gson.fromJson(value, listType);
    }

    @TypeConverter
    public static String fromList(List<Observation> list) {
        return gson.toJson(list);
    }
}