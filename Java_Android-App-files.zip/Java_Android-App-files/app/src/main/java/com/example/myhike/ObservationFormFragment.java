package com.example.myhike;

import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.example.myhike.model.Hike;
import com.example.myhike.model.Observation;
import com.example.myhike.repository.HikeRepository;

import org.parceler.Parcels;

import java.util.Calendar;
import java.util.Locale;

public class ObservationFormFragment extends Fragment {
    private EditText editTextObservation;
    private EditText editTextTime;
    private EditText editTextAdditionalComments;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_observation_form, container, false);
        editTextObservation = view.findViewById(R.id.editTextObservation);
        editTextTime = view.findViewById(R.id.editTextTime);
        editTextAdditionalComments = view.findViewById(R.id.editTextAdditionalComments);

        editTextTime.setOnClickListener(v -> showTimePickerDialog());

        Bundle args = getArguments();
        if (args != null && args.containsKey("selected_observation")) {
            Observation selectedObservation = Parcels.unwrap(args.getParcelable("selected_observation"));
            if (selectedObservation != null) {
                editTextObservation.setText(selectedObservation.getObservation());
                editTextTime.setText(selectedObservation.getTime());
                editTextAdditionalComments.setText(selectedObservation.getAdditionalComments());
            }
        }

        Button btnSave = view.findViewById(R.id.buttonSave);
        btnSave.setOnClickListener(v -> saveObservation());


        return view;
    }

    private void showTimePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(
                requireContext(),
                (view, selectedHour, selectedMinute) -> {
                    String selectedTime = String.format(Locale.getDefault(), "%02d:%02d", selectedHour, selectedMinute);
                    editTextTime.setText(selectedTime);
                },
                hour, minute, true);

        timePickerDialog.show();
    }
    private void saveObservation() {
        String observationTitle = editTextObservation.getText().toString();
        String time = editTextTime.getText().toString();
        String additionalComments = editTextAdditionalComments.getText().toString();

        if (observationTitle.isEmpty() || time.isEmpty()) {
            Toast.makeText(requireContext(), "Please fill in all required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        ProgressDialog progressDialog = ProgressDialog.show(requireContext(), "Saving Observation", "Please wait...", true);
        Bundle args = getArguments();
        Hike selectedHike = Parcels.unwrap(args.getParcelable("selected_hike"));
        Observation observation = new Observation(selectedHike.getId(), observationTitle, time, additionalComments);
        Log.e("ObservationsFormFragment", selectedHike.getHikeName());

        if (getArguments() != null && getArguments().containsKey("selected_observation")) {
            Observation selectedObservation = Parcels.unwrap(args.getParcelable("selected_observation"));
            observation.setId(selectedObservation.getId());
            new ObservationFormFragment.UpdateObservationTask(progressDialog).execute(observation);
        } else {
            Log.e("ObservationsFormFragment", "Inserting new observation");

            new ObservationFormFragment.InsertObservationTask(progressDialog).execute(observation);
        }
    }

    private class InsertObservationTask extends AsyncTask<Observation, Void, Void> {
        private ProgressDialog progressDialog;

        InsertObservationTask(ProgressDialog progressDialog) {
            this.progressDialog = progressDialog;
        }

        @Override
        protected Void doInBackground(Observation... observations) {
            if (observations != null && observations.length > 0) {
                HikeRepository hikeRepository = new HikeRepository(requireContext());
                hikeRepository.insertObservation(observations[0]);
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            progressDialog.dismiss();
            Toast.makeText(requireContext(), "Observation saved successfully", Toast.LENGTH_SHORT).show();
            Bundle bundle = getArguments();
            Navigation.findNavController(requireView()).navigate(R.id.hikeDetailsFragment, bundle);
        }
    }

    private class UpdateObservationTask extends AsyncTask<Observation, Void, Void> {
        private ProgressDialog progressDialog;

        UpdateObservationTask(ProgressDialog progressDialog) {
            this.progressDialog = progressDialog;
        }

        @Override
        protected Void doInBackground(Observation... observations) {
            if (observations != null && observations.length > 0) {
                HikeRepository hikeRepository = new HikeRepository(requireContext());
                hikeRepository.updateObservation(observations[0]);
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            progressDialog.dismiss();
            Toast.makeText(requireContext(), "Observation saved successfully", Toast.LENGTH_LONG).show();
            Bundle bundle = getArguments();
            Navigation.findNavController(requireView()).navigate(R.id.hikeDetailsFragment, bundle);

        }
    }

}
