package com.example.myhike.db;


import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.example.myhike.dao.HikeDao;
import com.example.myhike.model.Hike;
import com.example.myhike.model.Observation;

@Database(entities = {Hike.class, Observation.class}, version = 2, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    public abstract HikeDao hikeDao();

    private static AppDatabase INSTANCE;

    public static synchronized AppDatabase getInstance(android.content.Context context) {
        if (INSTANCE == null) {
            INSTANCE = androidx.room.Room.databaseBuilder(context.getApplicationContext(),
                            AppDatabase.class, "hikes-database")
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return INSTANCE;
    }
}