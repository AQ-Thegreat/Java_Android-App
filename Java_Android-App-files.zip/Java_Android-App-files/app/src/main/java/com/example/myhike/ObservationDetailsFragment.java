package com.example.myhike;

import android.app.AlertDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.example.myhike.model.Hike;
import com.example.myhike.model.Observation;
import com.example.myhike.repository.HikeRepository;

import org.parceler.Parcels;

import java.util.List;

public class ObservationDetailsFragment extends Fragment {
    private static final String OBSERVATION_KEY = "selected_observation";
    private HikeRepository hikeRepository;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_observation_details, container, false);


        // require the hike repo
        hikeRepository = new HikeRepository(requireContext());

        TextView observationNameTextView = view.findViewById(R.id.textview_observation_name);
        TextView observationDetailsTextView = view.findViewById(R.id.textview_observation_details);

        Bundle args = getArguments();
        if (args != null && args.containsKey(OBSERVATION_KEY)) {
            Observation selectedObservation = Parcels.unwrap(args.getParcelable(OBSERVATION_KEY));
            if (selectedObservation != null) {
                observationNameTextView.setText(selectedObservation.getObservation());
                String details = "Time: " + selectedObservation.getTime() + "\n"
                        + "Additional Comments: " + selectedObservation.getAdditionalComments() + "\n";
                observationDetailsTextView.setText(details);
            } else {
                Log.e("ObservationDetailsFragment", "selectedObservation is null");
            }

            Button btnDelete = view.findViewById(R.id.buttonDelete);
            btnDelete.setOnClickListener(v -> {
                confirmDeleteObservation();
            });

            Button btnEdit = view.findViewById(R.id.buttonEdit);
            btnEdit.setOnClickListener(v -> {
                Bundle bundle = getArguments();
                bundle.putParcelable("selected_observation", Parcels.wrap(selectedObservation));

                Navigation.findNavController(view)
                        .navigate(R.id.action_observationDetailsFragment_to_observationFormFragment, bundle);
            });


        } else {
            Log.e("ObservationDetailsFragment", "Bundle is null or doesn't contain key 'selected_observation'");
        }

        return view;
    }

    private void confirmDeleteObservation() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(requireContext());
        alertDialogBuilder.setTitle("Confirm Delete");
        alertDialogBuilder.setMessage("Are you sure you want to delete this observation?");
        alertDialogBuilder.setPositiveButton("Yes", (dialog, which) -> {
            deleteObservationAsync();
        });
        alertDialogBuilder.setNegativeButton("No", (dialog, which) -> {

        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void deleteObservationAsync() {
        Bundle args = getArguments();
        Observation selectedObservation = Parcels.unwrap(args.getParcelable(OBSERVATION_KEY));

        if (selectedObservation != null) {
            new DeleteObservationTask().execute(selectedObservation);
        } else {

        }
    }

    private class DeleteObservationTask extends AsyncTask<Observation, Void, Void> {

        @Override
        protected Void doInBackground(Observation... observations) {
            if (observations != null && observations.length > 0) {
                Observation observation = observations[0];
                HikeRepository hikeRepository = new HikeRepository(requireContext());
                hikeRepository.deleteObservation(observation);
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            Navigation.findNavController(requireView()).navigateUp();
        }
    }



}
