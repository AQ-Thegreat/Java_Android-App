package com.example.myhike;

import android.app.AlertDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.example.myhike.model.Hike;
import com.example.myhike.model.Observation;
import com.example.myhike.repository.HikeRepository;

import org.parceler.Parcels;

import java.util.List;

public class HikeDetailsFragment extends Fragment {
    private static final String HIKE_KEY = "selected_hike";
    private HikeRepository hikeRepository;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_hike_details, container, false);


        hikeRepository = new HikeRepository(requireContext());
        Bundle args = getArguments();

        ListView listView = view.findViewById(R.id.listView_observations);
        ArrayAdapter<Observation> adapter = new ArrayAdapter<>(requireContext(),
                                        android.R.layout.simple_list_item_1);
        listView.setAdapter(adapter);
        new LoadObservationsTask(adapter).execute();
            listView.setOnItemClickListener((parent, view1, position, id) -> {
                Observation selectedObservation = adapter.getItem(position);
                if (selectedObservation != null) {
                    Bundle bundle = new Bundle();
                    Hike selectedHike = Parcels.unwrap(args.getParcelable(HIKE_KEY));
                    bundle.putParcelable("selected_observation", Parcels.wrap(selectedObservation));
                    Log.e("HikeList", selectedHike.getHikeName());
                    bundle.putParcelable(HIKE_KEY,Parcels.wrap(selectedHike));
                    Navigation.findNavController(view)
                            .navigate(R.id.action_hikeDetailsFragment_to_observationDetailsFragment, bundle);
                }
            });
        TextView hikeNameTextView = view.findViewById(R.id.textview_hike_name);
        TextView hikeDetailsTextView = view.findViewById(R.id.textview_hike_details);

        if (args != null && args.containsKey(HIKE_KEY)) {
            Hike selectedHike = Parcels.unwrap(args.getParcelable(HIKE_KEY));
            if (selectedHike != null) {
                hikeNameTextView.setText(selectedHike.getHikeName());
                String details = "Location: " + selectedHike.getLocation() + "\n"
                        + "Parking available: " + selectedHike.getParkingAvailable() + "\n"
                        + "Length: " + selectedHike.getLength() + " miles\n"
                        + "Difficulty: " + selectedHike.getDifficultyLevel() + "\n"
                        + "Description: " + selectedHike.getDescription();
                hikeDetailsTextView.setText(details);
            } else {
                Log.e("HikeDetailsFragment", "selectedHike is null");
            }

            Button btnDelete = view.findViewById(R.id.buttonDelete);
            btnDelete.setOnClickListener(v -> {
                confirmDeleteHike();
            });

            Button btnEdit = view.findViewById(R.id.buttonEdit);
            btnEdit.setOnClickListener(v -> {
                Bundle bundle = new Bundle();
                bundle.putParcelable("selected_hike", Parcels.wrap(selectedHike));

                Navigation.findNavController(view)
                        .navigate(R.id.action_hikeDetailsFragment_to_hikeFormFragment, bundle);
            });
            Button btnAddObservation = view.findViewById(R.id.buttonAddObservation);
            btnAddObservation.setOnClickListener(v -> {
                Bundle bundle = new Bundle();
                bundle.putParcelable("selected_hike", Parcels.wrap(selectedHike));

                Navigation.findNavController(view)
                        .navigate(R.id.action_hikeDetailsFragment_to_observationFormFragment, bundle);
            });

        } else {
            Log.e("HikeDetailsFragment", "Bundle is null or doesn't contain key 'selected_hike'");
        }

        return view;
    }

    private void confirmDeleteHike() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(requireContext());
        alertDialogBuilder.setTitle("Confirm Delete");
        alertDialogBuilder.setMessage("Are you sure you want to delete this hike?");
        alertDialogBuilder.setPositiveButton("Yes", (dialog, which) -> {
            deleteHikeAsync();
        });
        alertDialogBuilder.setNegativeButton("No", (dialog, which) -> {

        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void deleteHikeAsync() {
        Bundle args = getArguments();
        Hike selectedHike = Parcels.unwrap(args.getParcelable(HIKE_KEY));

        if (selectedHike != null) {
            new DeleteHikeTask().execute(selectedHike);
        } else {

        }
    }

    private class DeleteHikeTask extends AsyncTask<Hike, Void, Void> {

        @Override
        protected Void doInBackground(Hike... hikes) {
            if (hikes != null && hikes.length > 0) {
                Hike hike = hikes[0]; // Get the first Hike object from the array
                HikeRepository hikeRepository = new HikeRepository(requireContext());
                hikeRepository.deleteHike(hike);
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);


            Navigation.findNavController(requireView()).navigateUp();
        }
    }


    private class LoadObservationsTask extends AsyncTask<Void, Void, List<Observation>> {
        private ArrayAdapter<Observation> adapter;

        LoadObservationsTask(ArrayAdapter<Observation> adapter) {
            this.adapter = adapter;
        }

        @Override
        protected List<Observation> doInBackground(Void... voids) {
            Bundle args = getArguments();
            Hike selectedHike = Parcels.unwrap(args.getParcelable(HIKE_KEY));
            return hikeRepository.getObservationsForHike(selectedHike.getId());
        }

        @Override
        protected void onPostExecute(List<Observation> observations) {
            super.onPostExecute(observations);
            adapter.clear();
            adapter.addAll(observations);
            adapter.notifyDataSetChanged();
        }
    }

}
